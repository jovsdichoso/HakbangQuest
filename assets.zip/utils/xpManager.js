// xpManager.js
import { doc, runTransaction, serverTimestamp, collection, addDoc, updateDoc } from "firebase/firestore"
import { db } from "../firebaseConfig"
import { ActivityTypeManager, ACTIVITY_TYPES } from "./ActivityTypeManager"
import { QuestProgressManager } from "./QuestProgressManager"

/**
 * Enhanced XP Manager with complete challenge and quest integration
 */
export class XPManager {
    /**
     * Main method to award XP for activities and handle all related progress
     */
    static async awardXPForActivity({
        userId,
        activityId,
        activityData,
        stats,
        activityParams = {},
        questData = null,
        challengeData = null,
        isStrengthActivity = false,
    }) {
        console.log("[v0] XPManager: Starting XP award process for activity:", activityId)

        try {
            return await runTransaction(db, async (transaction) => {
                // Check if XP already awarded (idempotency)
                const receiptRef = doc(db, "activity_receipts", activityId)
                const receiptDoc = await transaction.get(receiptRef)

                if (receiptDoc.exists()) {
                    console.log("[v0] XP already awarded for this activity")
                    return {
                        success: true,
                        alreadyAwarded: true,
                        xpEarned: receiptDoc.data().xpEarned,
                        questCompleted: receiptDoc.data().questCompleted || false,
                        challengeCompleted: receiptDoc.data().challengeCompleted || false,
                    }
                }

                // Get user data
                const userRef = doc(db, "users", userId)
                const userDoc = await transaction.get(userRef)

                if (!userDoc.exists()) {
                    throw new Error("User document not found")
                }

                const userData = userDoc.data()

                // Check activity completion criteria
                const completionCheck = this.checkActivityCompletion(stats, isStrengthActivity)
                if (!completionCheck.isComplete) {
                    console.log("[v0] Activity does not meet completion criteria:", completionCheck.reason)
                    return {
                        success: false,
                        reason: completionCheck.reason,
                        xpEarned: 0,
                        questCompleted: false,
                        challengeCompleted: false,
                    }
                }

                // Determine activity type
                const typeConfig = ActivityTypeManager.determineActivityType(activityParams)

                // Calculate XP based on activity type
                const xpCalculation = this.calculateXPByType(stats, typeConfig, questData, challengeData, isStrengthActivity)

                // Update user XP and stats
                const currentXP = userData.totalXP || 0
                const currentLevel = userData.level || 1
                const newTotalXP = currentXP + xpCalculation.totalXP
                const newLevel = Math.floor(newTotalXP / 1000) + 1

                const userUpdateData = {
                    totalXP: newTotalXP,
                    level: newLevel,
                    lastActivityDate: serverTimestamp(),
                    totalActivities: (userData.totalActivities || 0) + 1,
                }

                // Add activity-specific stats
                if (isStrengthActivity) {
                    userUpdateData.totalReps = (userData.totalReps || 0) + (stats.reps || 0)
                    userUpdateData.totalStrengthDuration = (userData.totalStrengthDuration || 0) + (stats.duration || 0)
                } else {
                    const distanceInKm = (stats.distance || 0) / 1000
                    userUpdateData.totalDistance = (userData.totalDistance || 0) + distanceInKm
                    userUpdateData.totalSteps = (userData.totalSteps || 0) + (stats.steps || 0)
                    userUpdateData.totalDuration = (userData.totalDuration || 0) + (stats.duration || 0)
                }

                // Update type-specific stats
                this.updateTypeSpecificStats(userUpdateData, typeConfig, xpCalculation)

                // Update user document
                transaction.update(userRef, userUpdateData)

                // Build complete activity data
                const completeActivityData = ActivityTypeManager.buildActivityData(
                    activityData,
                    typeConfig,
                    questData,
                    challengeData,
                )

                // Add XP data
                completeActivityData.xpEarned = xpCalculation.totalXP
                completeActivityData.bonusXP = xpCalculation.bonusXP
                completeActivityData.questCompleted = xpCalculation.questCompleted
                completeActivityData.challengeCompleted = xpCalculation.challengeCompleted

                // Save to appropriate collection
                const collectionName = ActivityTypeManager.getStorageCollection(typeConfig.type)
                const activityRef = doc(db, collectionName, activityId)
                transaction.set(activityRef, completeActivityData)

                // Handle quest completion
                if (xpCalculation.questCompleted && questData) {
                    await this.handleQuestCompletion(
                        transaction,
                        userId,
                        questData,
                        typeConfig,
                        xpCalculation,
                        activityId,
                        stats,
                        isStrengthActivity
                    )
                }

                // Handle challenge completion and progress
                if (challengeData) {
                    await this.handleChallengeProgress(
                        transaction,
                        userId,
                        challengeData,
                        stats,
                        xpCalculation,
                        activityId,
                        isStrengthActivity
                    )
                }

                // Create receipt
                const receiptData = {
                    userId: userId,
                    activityId: activityId,
                    activityType: typeConfig.type,
                    xpEarned: xpCalculation.totalXP,
                    questCompleted: xpCalculation.questCompleted,
                    challengeCompleted: xpCalculation.challengeCompleted,
                    awardedAt: serverTimestamp(),
                }
                transaction.set(receiptRef, receiptData)

                console.log("[v0] XP awarded successfully:", {
                    activityType: typeConfig.type,
                    totalXP: xpCalculation.totalXP,
                    newLevel: newLevel,
                    levelUp: newLevel > currentLevel,
                })

                return {
                    success: true,
                    alreadyAwarded: false,
                    activityType: typeConfig.type,
                    xpEarned: xpCalculation.totalXP,
                    questCompleted: xpCalculation.questCompleted,
                    challengeCompleted: xpCalculation.challengeCompleted,
                    levelUp: newLevel > currentLevel,
                    newLevel: newLevel,
                    bonusXP: xpCalculation.bonusXP,
                }
            })
        } catch (error) {
            console.error("[v0] XPManager: Error awarding XP:", error)
            throw error
        }
    }

    /**
     * Handle challenge progress and completion
     */
    static async handleChallengeProgress(transaction, userId, challengeData, stats, xpCalculation, activityId, isStrengthActivity) {
        const challengeRef = doc(db, "challenges", challengeData.id)
        const challengeDoc = await transaction.get(challengeRef)

        if (!challengeDoc.exists()) {
            console.warn("[v0] Challenge document not found:", challengeData.id)
            return
        }

        const challenge = challengeDoc.data()
        const updatedProgress = { ...challenge.progress }
        const updatedStatus = { ...challenge.status }

        // Calculate progress value based on challenge unit
        let progressValue = 0
        if (challenge.unit === "reps" && isStrengthActivity) {
            progressValue = stats.reps || 0
        } else if (challenge.unit === "distance" && !isStrengthActivity) {
            progressValue = (stats.distance || 0) / 1000 // meters to km
        } else if (challenge.unit === "duration") {
            progressValue = (stats.duration || 0) / 60 // seconds to minutes
        } else if (challenge.unit === "steps" && !isStrengthActivity) {
            progressValue = stats.steps || 0
        } else if (challenge.unit === "calories") {
            progressValue = stats.calories || 0
        }

        // Add to existing progress
        const currentProgress = updatedProgress[userId] || 0
        const newProgress = currentProgress + progressValue
        updatedProgress[userId] = newProgress

        // Check if challenge is completed
        const isCompleted = challenge.goal > 0 && newProgress >= challenge.goal
        if (isCompleted) {
            updatedStatus[userId] = "completed"

            // Handle challenge completion rewards
            await this.distributeChallengeRewards(transaction, userId, challengeData, challenge)
        } else {
            updatedStatus[userId] = "in_progress"
        }

        // Update challenge document
        transaction.update(challengeRef, {
            progress: updatedProgress,
            status: updatedStatus,
            lastUpdated: serverTimestamp(),
        })

        // Record challenge participation
        const participationRef = doc(collection(db, "challenge_participations"))
        const participationData = {
            challengeId: challengeData.id,
            userId: userId,
            activityId: activityId,
            progressValue: progressValue,
            totalProgress: newProgress,
            completed: isCompleted,
            participatedAt: serverTimestamp(),
        }
        transaction.set(participationRef, participationData)

        return {
            progress: newProgress,
            completed: isCompleted,
            goal: challenge.goal
        }
    }

    /**
     * Distribute challenge rewards to winners
     */
    static async distributeChallengeRewards(transaction, userId, challengeData, challenge) {
        const participants = Object.keys(challenge.progress || {})
        const totalStakeXP = (challenge.stakeXP || 100) * participants.length

        // For simplicity, winner takes all (can be enhanced for multiple winners)
        const winnerUpdateData = {
            totalXP: increment(totalStakeXP),
            completedChallenges: increment(1)
        }

        const winnerRef = doc(db, "users", userId)
        transaction.update(winnerRef, winnerUpdateData)

        // Create reward record
        const rewardRef = doc(collection(db, "challenge_rewards"))
        const rewardData = {
            challengeId: challengeData.id,
            winnerId: userId,
            stakeXP: challenge.stakeXP || 100,
            totalReward: totalStakeXP,
            distributedAt: serverTimestamp(),
        }
        transaction.set(rewardRef, rewardData)
    }

    /**
     * Calculate XP based on activity type
     */
    static calculateXPByType(stats, typeConfig, questData, challengeData, isStrengthActivity) {
        const baseXP = 50 // Base XP for completed activity
        let bonusXP = 0
        let questXP = 0
        let challengeXP = 0
        let questCompleted = false
        let challengeCompleted = false
        let achievedValue = 0

        // Calculate performance bonus XP
        bonusXP = this.calculatePerformanceBonusXP(stats, isStrengthActivity)

        // Quest XP calculation using QuestProgressManager
        if (questData) {
            const questResult = this.calculateQuestXP(stats, questData, isStrengthActivity)
            questXP = questResult.xp
            questCompleted = questResult.completed
            achievedValue = questResult.achievedValue
        }

        // Challenge XP calculation
        if (challengeData) {
            const challengeResult = this.calculateChallengeXP(stats, challengeData, isStrengthActivity)
            challengeXP = challengeResult.xp
            challengeCompleted = challengeResult.completed
        }

        const totalXP = baseXP + bonusXP + questXP + challengeXP

        return {
            baseXP,
            bonusXP,
            questXP,
            challengeXP,
            totalXP,
            questCompleted,
            challengeCompleted,
            achievedValue,
        }
    }

    /**
     * Calculate quest-specific XP using QuestProgressManager
     */
    static calculateQuestXP(stats, questData, isStrengthActivity) {
        if (!questData) return { xp: 0, completed: false, achievedValue: 0 }

        // Use QuestProgressManager for consistent progress calculation
        const sessionStats = { ...stats }
        if (questData.unit === "distance") {
            sessionStats.distance = sessionStats.distance || 0
        }

        const progressPercentage = QuestProgressManager.getProgressPercentage(
            questData,
            sessionStats,
            stats.calories || 0
        )

        const completed = progressPercentage >= 0.99
        const xp = completed ? questData.xpReward || 0 : 0
        const achievedValue = QuestProgressManager.getTotalValue(questData, sessionStats, stats.calories || 0)

        return { xp, completed, achievedValue }
    }

    /**
     * Calculate challenge-specific XP
     */
    static calculateChallengeXP(stats, challengeData, isStrengthActivity) {
        if (!challengeData) return { xp: 0, completed: false }

        // Challenge XP is awarded based on participation and goal achievement
        let xp = 0
        let completed = false

        if (challengeData.stakeXP) {
            // XP is distributed via stakes, not directly awarded
            xp = 0
        } else {
            // Regular challenge completion reward
            xp = challengeData.xpReward || 100
        }

        // Completion is determined by progress tracking, not here
        completed = false

        return { xp, completed }
    }

    /**
     * Handle quest completion
     */
    static async handleQuestCompletion(transaction, userId, questData, typeConfig, xpCalculation, activityId, stats, isStrengthActivity) {
        const questCompletionRef = doc(db, "quest_completions", `${userId}_${questData.id}_${Date.now()}`)

        // Use QuestProgressManager for accurate value calculation
        const sessionStats = { ...stats }
        const achievedValue = QuestProgressManager.getTotalValue(questData, sessionStats, stats.calories || 0)

        const questCompletionData = {
            questId: questData.id,
            userId: userId,
            questTitle: questData.title,
            questDescription: questData.description,
            questGoal: questData.goal,
            questUnit: questData.unit,
            achievedValue: achievedValue,
            activityType: typeConfig.type,
            xpEarned: questData.xpReward || 0,
            completedAt: serverTimestamp(),
            activityId: activityId,
            isFromChallenge: typeConfig.type === ACTIVITY_TYPES.CHALLENGE,
            challengeId: typeConfig.challengeId || null,
        }
        transaction.set(questCompletionRef, questCompletionData)
    }

    /**
     * Update type-specific user stats
     */
    static updateTypeSpecificStats(userUpdateData, typeConfig, xpCalculation) {
        switch (typeConfig.type) {
            case ACTIVITY_TYPES.CHALLENGE:
                userUpdateData.totalChallengeActivities = (userUpdateData.totalChallengeActivities || 0) + 1
                if (xpCalculation.challengeCompleted) {
                    userUpdateData.completedChallenges = (userUpdateData.completedChallenges || 0) + 1
                }
                break
            case ACTIVITY_TYPES.QUEST:
                userUpdateData.totalQuestActivities = (userUpdateData.totalQuestActivities || 0) + 1
                if (xpCalculation.questCompleted) {
                    userUpdateData.completedQuests = (userUpdateData.completedQuests || 0) + 1
                }
                break
            case ACTIVITY_TYPES.NORMAL:
            default:
                userUpdateData.totalNormalActivities = (userUpdateData.totalNormalActivities || 0) + 1
                break
        }
    }

    /**
     * Check if activity meets minimum completion criteria
     */
    static checkActivityCompletion(stats, isStrengthActivity) {
        if (isStrengthActivity) {
            if ((stats.reps || 0) < 5) {
                return {
                    isComplete: false,
                    reason: "Minimum 5 repetitions required",
                }
            }
            if ((stats.duration || 0) < 30) {
                return {
                    isComplete: false,
                    reason: "Minimum 30 seconds duration required",
                }
            }
        } else {
            const distanceInKm = (stats.distance || 0) / 1000
            const duration = stats.duration || 0

            if (distanceInKm < 0.1) {
                return {
                    isComplete: false,
                    reason: "Minimum 0.1 km distance required",
                }
            }
            if (duration < 60) {
                return {
                    isComplete: false,
                    reason: "Minimum 1 minute duration required",
                }
            }
        }

        return { isComplete: true }
    }

    /**
     * Calculate performance-based bonus XP
     */
    static calculatePerformanceBonusXP(stats, isStrengthActivity) {
        let bonusXP = 0

        if (isStrengthActivity) {
            bonusXP += Math.floor((stats.reps || 0) / 10) * 5 // 5 XP per 10 reps
            bonusXP += Math.floor((stats.duration || 0) / 300) * 10 // 10 XP per 5 minutes
        } else {
            const distanceInKm = (stats.distance || 0) / 1000
            bonusXP += Math.floor(distanceInKm) * 10 // 10 XP per km
            bonusXP += Math.floor((stats.duration || 0) / 600) * 5 // 5 XP per 10 minutes
            bonusXP += Math.floor((stats.steps || 0) / 1000) * 2 // 2 XP per 1000 steps
        }

        return bonusXP
    }

    /**
     * Generate deterministic activity ID based on user and session
     */
    static generateActivityId(userId, sessionStartTime, activityType = "normal") {
        return `${userId}_${sessionStartTime}_${activityType}`
    }
}